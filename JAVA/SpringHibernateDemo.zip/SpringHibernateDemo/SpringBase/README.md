# SpringHibernateDemo
SpringMVC和SpringHibernate整合的例子
